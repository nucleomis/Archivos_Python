from django.apps import AppConfig


class CarroConfig(AppConfig):
    name = 'carro'
